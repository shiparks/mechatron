N= [22.12]
D= [1 142.7 85.6 301.1]
T= tf(N,D)

close all

Kp= 1;
Ki= 0;

Gc=pid(Kp,Ki);
To= Gc*T;

Tc= feedback(To,1)
t = 60;
hold on
step(Tc,t)
hold off
stepinfo(Tc)

%%For Kp2
Kp2= 10;
Gc2 = pid(Kp2,Ki);

To2 = Gc2*T;
Tc2 = feedback(To2,1);
hold on
step(Tc2,t)
hold off
stepinfo(Tc2)

%%For Kp3
Kp3 = 100;
Gc3 = pid(Kp3,Ki);

To3 = Gc3*T;
Tc3 = feedback(To3,1);
hold on
step(Tc3,t);
legend('Kp = 1','Kp = 10','Kp = 100')
hold off
stepinfo(Tc3)


%%
%%For Ki1
figure
Kp= 1;
Ki= 1;

Gc=pid(Kp,Ki);
To= Gc*T;

Tc= feedback(To,1)
t = 60;
hold on
step(Tc,t)
hold off
stepinfo(Tc)

%For Ki2
Ki2= 2;
Gc2 = pid(Kp,Ki2);

To2 = Gc2*T;
Tc2 = feedback(To2,1);
hold on
step(Tc2,t)
hold off
stepinfo(Tc2)

%For Ki3
Ki3 = 3;
Gc3 = pid(Kp,Ki3);

To3 = Gc3*T;
Tc3 = feedback(To3,1);
hold on
step(Tc3,t);
legend('Ki = 1', 'Ki = 2', 'Ki = 3');
hold off
stepinfo(Tc3)


