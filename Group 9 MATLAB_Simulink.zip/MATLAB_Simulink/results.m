close all

open_system("Controlled_NonLinear");
out = sim("Controlled_NonLinear.slx",'SaveState','on')

time=out.ScopeData.time;
theta=out.ScopeData.signals(4).values;

plot(time,theta*180/pi)
box off
grid minor
grid on
box off
ylabel('\Theta')
xlabel('time')

V=out.ScopeData.signals(2).values;
I=out.ScopeData.signals(3).values;
O=out.ScopeData.signals(4).values;

figure

subplot(2,1,1)
plot(time,V)
box off
grid minor
grid on
box off
ylabel('Voltage')
xlabel('time')


subplot(2,1,2)
plot(time,I*180/pi,'r'); hold on;
plot(time,O*180/pi,'--b');hold on;
box off
grid minor
grid on
box off
ylabel('\Theta')
xlabel('time')

legend('Sun trajectory','Solar tracker position')