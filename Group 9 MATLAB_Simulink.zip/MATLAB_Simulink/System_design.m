N= [22.12]
D= [1 142.7 85.6 301.1]

T= tf(N,D)
close all

KP= 0.83;
KI= 2.85;

Gc=pid(KP,KI)
To= Gc*T

Tc= feedback(To,1)
t = 60;
step(T,t)
hold
step(Tc,t)
legend('Uncontrolled system response','PI controlled system response');

% stepinfo(T)
% 
figure 
bode(Tc)

% 
figure;
rlocus(Tc)
% clc
figure
pzmap(Tc)
